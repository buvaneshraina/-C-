﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var x= Console.ReadLine();
            Console.WriteLine("your value:" + x);
        }
    }
}
