﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* Append a string */
            string f = "Bravo";
            Console.WriteLine("Hello " + f);
            Console.WriteLine($"Hello {f} ");

            /* Letters length */
            string Lover = "Romeo";
            string Love = "Juliath";

            Console.WriteLine($"The Lovers are {Lover} and {Love}");
            Console.WriteLine($"The Name  {Lover} has {Lover.Length} letters");
            Console.WriteLine($"The Name  {Lover} has {Love.Length} letters");

            /* Trimming a string */
            string greeting = "      Good Morning !   ";
            Console.WriteLine($"[{greeting}] ");

            string trimStartgreeting = greeting.TrimStart();
            Console.WriteLine($"[{trimStartgreeting}] ");

            string trimendgreeting = greeting.TrimEnd();
            Console.WriteLine($"[{trimendgreeting}] ");

            string trimgreeting = greeting.Trim();
            Console.WriteLine($"[{trimgreeting}] ");

            /* Replacing a string */
            string Intro = "Hi , How are you !";
            Console.WriteLine(Intro);

            Intro = Intro.Replace("How", "Where");
            Console.WriteLine(Intro);

            /* Changing a string to upper and lower case */
            Console.WriteLine(Intro.ToLower());
            Console.WriteLine(Intro.ToUpper());
        }
    }
}
