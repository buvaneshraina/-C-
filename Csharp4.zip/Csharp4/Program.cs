﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp4
{
    public class Program
    {
        public static void Main(string[] args)
        {
            /* String boolean*/

            string conversation = "Finish the work without fail";

            Console.WriteLine(conversation.Contains("Finish"));

            Console.WriteLine(conversation.Contains("faill"));

            var result = conversation.StartsWith("Finish");

            Console.WriteLine(result);

            /* integer math */

            int a = 30;
            int b = 20;
            int c = 10;

            int aa = a + b;
            int d = a / b;
            int s = a - b;
            int M = a * b;

            int cc = a + b * c;

            Console.WriteLine(aa);
            Console.WriteLine(d);
            Console.WriteLine(s);
            Console.WriteLine(M);
            Console.WriteLine(cc);



        }
    }
}
