﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp5
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            /* reminder & quotient */

            int a = 3;
            int b= 4;
            int c = 5;
            int d = a + b / c;
            int e= a+b  %c;
            Console.WriteLine($"quotient:{ d}");
            Console.WriteLine($"reminder:{ e}");

            /* mathematical integers */
            int max =int.MaxValue;
            int min=int.MinValue;
            Console.WriteLine($"The range of integers is {min} and {max}");


            /* An example of over flow */
            int overflow = max + 10;
            Console.WriteLine($"An example of overflow number is:{overflow}");

            /* double integer */
            double ad = 5;
            double bd = 4;
            double cd= 2;
            double dd = (ad + bd) / cd;
            Console.WriteLine(dd);

            double maxd = double.MaxValue;
            double mind = double.MinValue;
            Console.WriteLine($"The range of double is{mind}  to {maxd}");

            double third = 1.0 / 3.0;
            Console.WriteLine(third);

            decimal cm = 1.0M;
            decimal dm = 3.0M;
            Console.WriteLine(cm / dm);

            int min2 = int.MinValue;
            int max2 = int.MaxValue;
            Console.WriteLine($"The range of the int type is {min2} to {max2}");

            short min3 = short.MinValue;
            short max3 = short.MaxValue;
            Console.WriteLine($"The range of the short type is {min3} to {max3}");

            long min4 = long.MinValue;
            long max4 = long.MaxValue;
            Console.WriteLine($"The range of the decimal type is {min4} to {max4}");

            double radius = 5.5;
            double area = Math.PI * radius * radius;
            Console.WriteLine(area);
        }
    }
}
