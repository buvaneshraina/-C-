﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp6
{
    public class Program
    {
        public static void Main(string[] args)
        {
            /* if condition*/
            int a = 80;
            int b = 100;
            if (a + b > 150)
                Console.WriteLine("The answer is a greater than 150");

            int d = 800;
            int e = 200;

            bool g = d + e > 1000;

            if (g)
                Console.WriteLine("The answer is a greater than 1000");

            int ag = 5;
            int bg = 3;
            if (ag + bg > 10)
                Console.WriteLine("The answer is greater than 10");
            else
                Console.WriteLine("The answer is not greater than 10");

            int agg = 5;
            int bgg = 3;
            if (agg + bgg > 10)
            {
                Console.WriteLine("The answer is greater than 10");
            }
            else
            {
                Console.WriteLine("The answer is not greater than 10");
            }

            /* And operator */
            int ah = 5;
            int bh = 3;
            int ch = 4;
            if ((ah + bh + ch > 10) && (ah == bh))
            {
                Console.WriteLine("The answer is greater than 10");
                Console.WriteLine("And the first number is equal to the second");
            }
            else
            {
                Console.WriteLine("The answer is not greater than 10");
                Console.WriteLine("Or the first number is not equal to the second");
            }
            /* Not operator */
            int aj = 5;
            int bj = 3;
            int cj = 4;
            if ((aj + bj + cj > 10) || (a == b))
            {
                Console.WriteLine("The answer is greater than 10");
                Console.WriteLine("And the first number is equal to the second");
            }
            else
            {
                Console.WriteLine("The answer is not greater than 10");
                Console.WriteLine("Or the first number is not equal to the second");
            }





        }
    }
}
